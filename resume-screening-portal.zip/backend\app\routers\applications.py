from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.application import Application
from app.models.job import Job
from app.schemas.application import (
    ApplicationCreate,
    ApplicationResponse,
    ApplicationStatusUpdate
)

router = APIRouter()


@router.post("/", response_model=ApplicationResponse)
def apply_for_job(
    application: ApplicationCreate,
    db: Session = Depends(get_db)
):
    """
    Apply for a job
    """

    job = db.query(Job).filter(
        Job.id == application.job_id
    ).first()

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Job not found"
        )

    existing_application = db.query(Application).filter(
        Application.candidate_id == 1,
        Application.job_id == application.job_id
    ).first()

    if existing_application:
        raise HTTPException(
            status_code=400,
            detail="Already applied for this job"
        )

    new_application = Application(
        candidate_id=1,  # temporary placeholder until auth is connected
        job_id=application.job_id,
        status="Applied"
    )

    db.add(new_application)
    db.commit()
    db.refresh(new_application)

    return new_application


@router.get("/my", response_model=list[ApplicationResponse])
def get_my_applications(
    db: Session = Depends(get_db)
):
    """
    View my applications
    """

    applications = db.query(Application).filter(
        Application.candidate_id == 1
    ).all()

    return applications


@router.get("/job/{job_id}", response_model=list[ApplicationResponse])
def get_applicants_for_job(
    job_id: int,
    db: Session = Depends(get_db)
):
    """
    View all applicants for a job
    """

    job = db.query(Job).filter(
        Job.id == job_id
    ).first()

    if not job:
        raise HTTPException(
            status_code=404,
            detail="Job not found"
        )

    applications = db.query(Application).filter(
        Application.job_id == job_id
    ).all()

    return applications


@router.put("/{application_id}", response_model=ApplicationResponse)
def update_application_status(
    application_id: int,
    payload: ApplicationStatusUpdate,
    db: Session = Depends(get_db)
):
    """
    Update application status
    """

    application = db.query(Application).filter(
        Application.id == application_id
    ).first()

    if not application:
        raise HTTPException(
            status_code=404,
            detail="Application not found"
        )

    application.status = payload.status

    db.commit()
    db.refresh(application)

    return application